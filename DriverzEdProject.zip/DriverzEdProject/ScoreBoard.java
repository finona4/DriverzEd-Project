import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ScoreBoard here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ScoreBoard extends Actor
{
    private int points;
    int control_counter=0;
    private Font myFont = new Font("Comic Sans MS", false, true, 24);
    public ScoreBoard(){
        points = 10;        
        GreenfootImage img = new GreenfootImage(150,30);
        img.setFont( myFont );
        img.drawString("Points: " + points, 5,25);
        setImage(img);  //make the scoreboard this text
    }

    /**
     * Act - do whatever the ScoreBoard wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    

    public void subPoints() 
    {
        control_counter++;
        if(control_counter>100){
            points--;
            control_counter=0;
        }
        GreenfootImage img = getImage();
        img.clear();
        setImage(img);
        if(points >1) {
            img.drawString("Points: " + points, 5,25);
        }
        else{
            ((MyWorld) getWorld()).gameOver();
        }
    }
}
