import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Line here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Line extends Actor
{
    public Line()
    {
        GreenfootImage img = new GreenfootImage(80,15);
        img.setColor(Color.YELLOW);
        img.fill();
        setImage(img);
    }

    /**
     * Act - do whatever the Line wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        moveDown();
    } 

    public void moveDown(){
        setLocation( getX()-3,  getY() );
        if (getX()<=0){
            getWorld().removeObject(this);
        }
    }
}
