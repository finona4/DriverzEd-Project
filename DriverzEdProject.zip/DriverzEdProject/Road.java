import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Road here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Road extends Actor
{
    public Road(){
        GreenfootImage img = new GreenfootImage( 2000, 200);
        img.drawRect(0, 0,800,200); 
        img.setColor(Color.GRAY);
        img.fill();
        setImage(img);
    }

    /**
     * Act - do whatever the Road wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
