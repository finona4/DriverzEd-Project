
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class OncomingCar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class OncomingCar extends Actor
{
    int speed = Greenfoot.getRandomNumber(3)+3;
    public OncomingCar(){
        setRotation(180);
    }

    /**
     * Act - do whatever the OncomingCar wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        moveLeft();        
    }    

    public void moveLeft(){
        setLocation(getX()-4, getY());
        Actor collided;
        collided = getOneIntersectingObject(Ambulance.class);
        if(isAtEdge() || collided != null){
            getWorld().removeObject(this);
        }
    }
}
