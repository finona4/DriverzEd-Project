import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ambulance here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ambulance extends Actor
{
    int direction=10;
    int counter=0;
    private GreenfootSound music = new GreenfootSound("siren.mp3");
    public Ambulance(){
    }

    /**
     * Act - do whatever the Ambulance wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(getX()<400){
            direction=10;
        }
        if(getY()<=300){
            setRotation(180);
            direction=-10;
        }
        music.play();
        counter++;
        if(counter>=100){
            move(3);
        }
        if(isAtEdge()){
            getWorld().removeObject(this);
        }
    }    
}
