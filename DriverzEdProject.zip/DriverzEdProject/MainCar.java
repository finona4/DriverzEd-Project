import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MainCar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MainCar extends Actor
{
    int speed=2;
    int brake=5;
    int counter=0;
    boolean speeding=false;
    boolean warning=false;
    private Font myFont = new Font("Comic Sans MS", false, true, 24);
    private GreenfootSound music = new GreenfootSound("aww.mp3");
    /**
     * Act - do whatever the MainCar wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        getWorld().showText("Speed:  "+speed+5, 100, 100);
        moving();
        crashes();
    }    

    public void moving(){
        if(Greenfoot.isKeyDown("up")){
            setLocation(getX(), getY()-3);
        }
        if(Greenfoot.isKeyDown("down")){
            setLocation(getX(), getY()+3);
        }
        if(Greenfoot.isKeyDown("right")){
            setLocation(getX()+speed, getY());
            counter++;
            if(counter<=99){
                speeding=false;
                brake=5;
            }
            if(counter==100){
                speeding=false;
                speed++;
                brake--;
            }
            if(counter==150){
                speed=(speed+2);
                brake=(brake-2);
                speeding=true;
            }
        }
        if(Greenfoot.isKeyDown("left")){
            speeding=false;
            counter=0;
            speed=2;
            setLocation(getX()-brake, getY());
        }
        if(getY()<=200 || getY()>=400){

        }
    }

    public void crashes(){
        if(((MyWorld) getWorld()).dead==false){
            if(isTouching(Girl1.class)){
                music.play();
                GreenfootImage img = new GreenfootImage(150,30);
                img.setFont( myFont );
                img.drawString("You hit a girl.", 400,400);
                setImage(img); 
            }
            if(isTouching(Guy1.class)){
                music.play();
                GreenfootImage img2 = new GreenfootImage(150,30);
                img2.setFont( myFont );
                img2.drawString("You hit a guy.", 400,400);
                setImage(img2); 
            }
        }
        if(isTouching(OncomingCar.class)){
            music.play();
        }
        if(isTouching(Ambulance.class)){
            music.play();
        }
        if(isTouching(Shoulder.class)){
            ((MyWorld) getWorld()).update();
        }
        if(speeding){
            ((MyWorld) getWorld()).update2();
        }
        if(isTouching(Girl1.class) || isTouching(Guy1.class) || isTouching(OncomingCar.class) || isTouching(Ambulance.class)){
            ((MyWorld) getWorld()).gameOver();
        }
    }

}