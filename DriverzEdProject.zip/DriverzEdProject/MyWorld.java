import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    private GreenfootSound music = new GreenfootSound("song.mp3");
    int counter=0;
    double a=52;
    boolean ambulance=false;
    int ambulance_counter=0;
    boolean dead=false;
    private ScoreBoard points;
    private ScoreBoard2 over;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        prepare();
        points=new ScoreBoard();
        addObject(points, 100, 50);
        over=new ScoreBoard2();
        addObject(over, 0, 0);
    }

    public void prepare(){
        setPaintOrder(Title.class, gameover.class, MainCar.class, OncomingCar.class,  Ambulance.class, Line.class, Road.class, Shoulder.class, Shoulder2. class);
        addObject(new Title(), 400, 300);
        addObject(new Road(), 0, 300);
        addObject(new Shoulder(), 0, 175);
        addObject(new Shoulder2(), 0, 425);
        addObject(new MainCar(), 100, 350);
        addObject(new Line(),0,300); 
        addObject(new Line(),180,300); 
        addObject(new Line(),360,300); 
        addObject(new Line(),540,300);
        addObject(new Line(),720,300);
    }

    public void started()
    {
        music.playLoop();  //to make the background music loop over once the game starts
    }

    public void act()
    {
        counter++;
        if (counter==a){
            addObject(new Line(), 800, 300);
            counter=0;
        }
        Ambulance();
        CP();
    }

    public void CP(){
        if(Greenfoot.getRandomNumber(1000)<=1){
            addObject(new OncomingCar(), 850, 250);
        }
        if(Greenfoot.getRandomNumber(1500)<=1){
            addObject(new Guy1(), Greenfoot.getRandomNumber(800), 100);
        }
        if(Greenfoot.getRandomNumber(1500)<=1){
            addObject(new Girl1(), Greenfoot.getRandomNumber(800), 100);
        }
        ambulance_counter++;
    }

    public void Ambulance(){
        if(ambulance==false){
            if(Greenfoot.getRandomNumber(1500)<=1){
                int whichlane=Greenfoot.getRandomNumber(10);
                ambulance=true;
                if(whichlane<5){
                    addObject(new Ambulance(), 2 , 350);
                }
                if(whichlane>=5){
                    addObject(new Ambulance(), 798 , 250);
                }
            }
        }
        if(ambulance_counter>=1500){
            ambulance_counter=0;
            ambulance=false;
        }
    }

    public void update(){
        if(ambulance==false){
            points.subPoints();
        }
    }

    public void update2(){
        points.subPoints();
    }

    public void gameOver(){
        dead=true;
        over.gameOver();
    }
}